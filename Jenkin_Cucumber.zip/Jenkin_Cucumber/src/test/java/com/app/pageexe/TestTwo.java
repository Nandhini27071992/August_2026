package com.app.pageexe;

import java.util.HashMap;

public abstract class TestTwo {
	public TestTwo() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		HashMap< Object, Object> map =new HashMap<Object, Object>();
		map.put(1, "a");
	}
}
